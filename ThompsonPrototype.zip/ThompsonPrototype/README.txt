Hi!

Prototype built for controller.

Controls: 
	Left Stick forward/backwards: scissor legs
	Left Stick left/right: turn skis
	Left/Right Trigger: shift weight left/right

Ben Haderle
@benhaderle
benhaderle@gmail.com

